package com.kh.practice2.score.run;

import com.kh.practice2.score.view.ScoreMenu;

public class Run {

	public static void main(String[] args) {
		new ScoreMenu().mainMenu();
	}

}
