package com.kh.practice2.run;

import com.kh.practice2.view.LeapView;

public class Run {

	public static void main(String[] args) {
		new LeapView();
	}

}
