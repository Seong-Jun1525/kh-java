package com.kh.practice2.run;

import com.kh.practice2.func.CastingPractice1;
import com.kh.practice2.func.CastingPractice2;
import com.kh.practice2.func.CastingPractice3;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CastingPractice1 cp1 = new CastingPractice1();
		CastingPractice2 cp2 = new CastingPractice2();
		CastingPractice3 cp3 = new CastingPractice3();
		
//		cp1.test();
//		cp2.test();
//		cp3.method();
	}

}
